
# Document Page Counter Script

This PowerShell script is designed to count the number of pages in Word and PDF documents within a specified folder. It supports `.docx` and `.pdf` file formats and displays the page count for each document in the console.

## Usage

1. Save the script to a `.ps1` file (e.g., `DocumentPageCount.ps1`).
2. Modify the `$folderPath` variable to point to the directory containing your documents.
3. Place `.pdf` or `.docx` documents in the folder that the path is pointing to.
4. Run the script.

The script will output the file name, page count, and document type for each `.docx` and `.pdf` file in the specified folder.

## Requirements

* PowerShell
* Microsoft Word installed on the machine (for counting pages in Word documents)
* Ensure the script has permissions to access the files in the specified folder.

## Notes

* The PDF page count method uses a simplified approach and may not be accurate for all PDF files. Consider using a more robust PDF library (like `iTextSharp`) for better accuracy.
* The script does not output the full path of the file but rather only the file name and page count.

## Author

* **Michael Mattingly**

  GitHub: [mamattingly](https://github.com/mamattingly)

## License

This script is licensed under the MIT License. See the [LICENSE](LICENSE) file for more details.
